#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pcap.h>
#include <arpa/inet.h>
#include "trace.h"
#include "checksum.h"

/* Function Declarations */
void ip(const u_char *packet);
void ethernet(const u_char *packet);
void icmp(const u_char *packet);
void arp(const u_char *packet);
void Udp(const u_char *packet);
void tcp(const u_char *packet, int len, int header_len);

/* ether_ntoa and inet_ntoa would not work - printing single digits for some address, made my own printer*/
void print_address(const u_char *addr) {
    for (int i = 0; i < 6; i++) {
        printf("%02x", addr[i]);   // zero-padded hex
        if (i < 5) {
            printf(":");
        }
    }
    printf("\n");
}


void ethernet(const u_char *packet){
    struct Ethernet eth_head;
    memcpy(&eth_head, packet, sizeof(struct Ethernet)); //copy packet to struct vals

    printf("\tEthernet Header\n");

    printf("\t\tDest MAC: ");
    print_address(eth_head.dest);

    printf("\t\tSource MAC: ");
    print_address(eth_head.source);
    
    /*IP type -> 0x0800, ARP type -> 0x0806*/
    unsigned short eth_type = ntohs(eth_head.type);
    if (eth_type == 0x0806){
        printf("\t\tType: ARP\n\n");
        arp(packet);
    }
    else if (eth_type == 0x0800){
        printf("\t\tType: IP\n\n");
        ip(packet);
    }
}

void ip(const u_char *packet){ //IP packet is from 0x0E --- 0x21
    struct IP ip_header;
    memcpy(&ip_header, packet + 14, sizeof(struct IP)); //ethernet is previous 14

    int header = ip_header.header_len & 0x0F; //extract low nibble
    int header_len = header * 4;

    uint16_t len = ntohs(ip_header.len);
    uint16_t checksum = ntohs(ip_header.checksum);
    /* uint16_t id = ntohs(ip_header.id); added these in beginning, got errors they were unused
 *     // uint16_t frag_off = ntohs(ip_header.frag_off);
 *         //if we wanted to use these for printing ^^ we could by just uncommenting
 *             //There are many instances like this throughout the file
 *                 // uint32_t source = ntohl(ip_header.source);
 *                     // uint32_t dest = ntohl(ip_header.dest); */

    printf("\tIP Header\n");
    printf("\t\tIP PDU Len: %u\n", len);
    printf("\t\tHeader Len (bytes): %u\n", header_len);
    printf("\t\tTTL: %u\n", ip_header.ttl);
    
    printf("\t\tProtocol: ");
    switch (ip_header.protocol)
    {
    case 1:
        printf("ICMP\n");
        break;
    case 6:
        printf("TCP\n");
        break;
    case 17:
        printf("UDP\n");
        break;
    default:
        printf("Unknown\n");
        break;
    }

    unsigned short chksum = in_cksum((unsigned short *)(packet + 14), header_len);
    printf("\t\tChecksum: ");
    if(chksum == 0){
        printf("Correct (0x%04x)\n", checksum);
    }else{
        printf("Incorrect (0x%04x)\n", checksum);
    }

    struct in_addr src_addr, dest_addr;
    src_addr.s_addr = ip_header.source;
    dest_addr.s_addr = ip_header.dest;
    
    printf("\t\tSender IP: %s\n", inet_ntoa(src_addr));
    printf("\t\tDest IP: %s\n\n", inet_ntoa(dest_addr));

    switch (ip_header.protocol)
    {
    case 1:
        icmp(packet + 14 + header_len); //14 (ethernet) + IP headerlen
        break;
    case 6:
        tcp(packet, len-header_len, header_len);
        break;
    case 17:
        Udp(packet + 14 + header_len);
        break;
    default:
        break;
    }
}

void icmp(const u_char *packet){
    struct ICMP icmp_header;
    memcpy(&icmp_header, packet, sizeof(struct ICMP)); //ethernet + IP is previous 34

    /* uint16_t checksum = ntohs(icmp_header.checksum);
 *      uint16_t id = ntohs(icmp_header.id);
 *           uint16_t sequence = ntohs(icmp_header.sequence); */

    printf("\tICMP Header\n");

    if(icmp_header.type == 0){
        printf("\t\tType: Reply\n\n");
    }
    else if (icmp_header.type == 8){
        printf("\t\tType: Request\n\n");
    }
    else{
        printf("\t\tType: %d\n\n", icmp_header.type);
    }

}

void arp(const u_char *packet){
    struct ARP arp_header;
    memcpy(&arp_header, packet + 14, sizeof(struct ARP)); //ethernet is previous 14

    /* uint16_t hw_type = ntohs(arp_header.hw_type); //hw type
 *      uint16_t prot_type = ntohs(arp_header.prot_type); //protocol type */
    uint16_t opcode = ntohs(arp_header.opcode); //opcode

    printf("\tARP header\n");
    if (opcode == 1){ //diff opcodes
        printf("\t\tOpcode: Request\n");
    }else if(opcode == 2){
        printf("\t\tOpcode: Reply\n");
    }


    struct in_addr temp_ip_addr;
    printf("\t\tSender MAC: ");
    print_address(arp_header.src_hw_mac);

    memcpy(&temp_ip_addr, arp_header.src_proto, 4);
    printf("\t\tSender IP: %s\n", inet_ntoa(temp_ip_addr));

    printf("\t\tTarget MAC: ");
    print_address(arp_header.dst_hw_mac);

    memcpy(&temp_ip_addr, arp_header.dst_proto, 4);
    printf("\t\tTarget IP: %s\n\n", inet_ntoa(temp_ip_addr));
     
}

void Udp(const u_char *packet){
    struct UDP udp_header;
    memcpy(&udp_header, packet, sizeof(struct UDP)); //not always +34 - need to figure out

    uint16_t src_port = ntohs(udp_header.src_port); //src port
    uint16_t dst_port = ntohs(udp_header.dst_port); //dst
    /* uint16_t len = ntohs(udp_header.len); //len
 *      uint16_t checksum = ntohs(udp_header.checksum); //checksum */

    printf("\tUDP Header\n");

    printf("\t\tSource Port: ");
    switch (src_port) //src ports other than actual number
    {
    case 21:
        printf("FTP\n");
        break;
    case 23:
        printf("Telnet\n");
        break;
    case 25:
        printf("SMTP\n");
        break;
    case 53:
        printf("DNS\n");
        break;
    case 80:
        printf("HTTP\n");
        break;
    case 110:
        printf("POP3\n");
        break;
    default:
        printf("%u\n", src_port);
        break;
    }

    printf("\t\tDest Port: ");
    switch (dst_port) //src ports other than actual number
    {
    case 21:
        printf("FTP\n\n");
        break;
    case 23:
        printf("Telnet\n\n");
        break;
    case 25:
        printf("SMTP\n\n");
        break;
    case 53:
        printf("DNS\n\n");
        break;
    case 80:
        printf("HTTP\n\n");
        break;
    case 110:
        printf("POP3\n\n");
        break;
    default:
        printf("%u\n\n", dst_port);
        break;
    }

}

void tcp(const u_char *packet, int len, int header_len){
    struct TCP tcp_header;
    memcpy(&tcp_header, packet + 14 + header_len, sizeof(struct TCP)); //ethernet + IP is previous 34

    struct IP ip_header; // for the checksum
    memcpy(&ip_header, packet + 14, sizeof(struct IP));

    /* convert all used vals to readable and correct vals */
    uint16_t srcport = ntohs(tcp_header.srcport);
    uint16_t dstport = ntohs(tcp_header.dstport);
    uint32_t seq_raw = ntohl(tcp_header.seq_raw);
    uint32_t ack_raw = ntohl(tcp_header.ack_raw);
    uint16_t window_size_value = ntohs(tcp_header.window_size_value);
    uint16_t checksum = ntohs(tcp_header.checksum);
    /*uint16_t urgent_pointer = ntohs(tcp_header.urgent_pointer);*/

    printf("\tTCP Header\n");
    printf("\t\tSegment Length: %d\n", len);

    printf("\t\tSource Port: ");
    switch (srcport) //src ports other than actual number
    {
    case 21:
        printf("FTP\n");
        break;
    case 23:
        printf("Telnet\n");
        break;
    case 25:
        printf("SMTP\n");
        break;
    case 53:
        printf("DNS\n");
        break;
    case 80:
        printf("HTTP\n");
        break;
    case 110:
        printf("POP3\n");
        break;
    default:
        printf("%u\n", srcport);
        break;
    }

    printf("\t\tDest Port: ");
    switch (dstport) //src ports other than actual number
    {
    case 21:
        printf("FTP\n");
        break;
    case 23:
        printf("Telnet\n");
        break;
    case 25:
        printf("SMTP\n");
        break;
    case 53:
        printf("DNS\n");
        break;
    case 80:
        printf("HTTP\n");
        break;
    case 110:
        printf("POP3\n");
        break;
    default:
        printf("%u\n", dstport);
        break;
    }

    printf("\t\tSequence Number: %u\n", seq_raw);
    printf("\t\tACK Number: %u\n", ack_raw);

    /* had to look up data offset, chat gpted flags and checksum, could not for the life of me figure out how to do either
 *     or even where to start, flags make sense, checksum makes more sense now kinda but still looking into it*/
    int data_offset = ((tcp_header.flags_ae & 0xF0) / 4); //extract offset - convert from 32 bit words to bytes based on flagae

    printf("\t\tData Offset (bytes): %d\n", data_offset);

    
    uint8_t flags = tcp_header.flags_fin;

    printf("\t\tSYN Flag: %s\n", (flags & 0x02) ? "Yes" : "No");
    printf("\t\tRST Flag: %s\n", (flags & 0x04) ? "Yes" : "No");
    printf("\t\tFIN Flag: %s\n", (flags & 0x01) ? "Yes" : "No");
    printf("\t\tACK Flag: %s\n", (flags & 0x10) ? "Yes" : "No");

    printf("\t\tWindow Size: %u\n", window_size_value);


    struct PseudoHeader pseudo;
    pseudo.src_addr = ip_header.source;
    pseudo.dst_addr = ip_header.dest;
    pseudo.zero = 0;
    pseudo.protocol = 6; // TCP protocol number
    pseudo.tcp_length = htons(len);

    int total_len = sizeof(struct PseudoHeader) + len;
    u_char *checksum_buffer = malloc(total_len);

    if (checksum_buffer) {
        
        memcpy(checksum_buffer, &pseudo, sizeof(struct PseudoHeader));// Copy pseudo-header
        
        memcpy(checksum_buffer + sizeof(struct PseudoHeader), packet + 14 + header_len, len);// Copy TCP segment (starting at packet + 34)
        
        unsigned short calculated_checksum = in_cksum((unsigned short *)checksum_buffer, total_len);// Calculate checksum
        
        printf("\t\tChecksum: ");
        if (calculated_checksum == 0) {
            printf("Correct (0x%04x)\n\n", checksum);
        } else {
            printf("Incorrect (0x%04x)\n\n", checksum);
        }
        
        free(checksum_buffer);
    }

}

int main (int argc, char *argv[]){
    if(argc != 2){
        fprintf(stderr, "Incorrect usage, Correct Usage: %s <pcap file>\n", argv[0]);
        exit(1);
    }

    /* setup off tcpdump.org for pcap reading */
    char errbuf[PCAP_ERRBUF_SIZE]; 
    pcap_t *fopen = pcap_open_offline(argv[1], errbuf);
    
    if(!fopen){ //check if pcap opened
        fprintf(stderr, "failed opening .pcap file");
        exit(1);
    }

    /*pcap struct from site, loop thru every packet, and parse*/
    struct pcap_pkthdr *packet_header;
    const u_char *packet;
    int num_packets = 0;
    printf("\n");
    while(pcap_next_ex(fopen, &packet_header, &packet) >= 0){
        
        printf("Packet number: %d  Packet Len: %d\n\n", ++num_packets, packet_header->len);
        ethernet(packet);
    }

    pcap_close(fopen);
    return 0;
}
