#ifndef TRACE_H
#define TRACE_H

#include <stdint.h>

struct Ethernet{
    unsigned char dest[6]; //destination
    unsigned char source[6]; //source
    unsigned short type; //ARP or IP
};

struct IP{
    uint8_t header_len; //header length
    uint8_t tos; //type of service
    uint16_t len; //total length
    uint16_t id; //identification
    uint16_t frag_off; //flags + offset
    uint8_t ttl; //time to live
    uint8_t protocol; //protocol
    uint16_t checksum; //checksum
    uint32_t source; // src address
    uint32_t dest; //destination
};

struct ICMP{
    uint8_t type;
    uint8_t code;
    uint16_t checksum;
    uint16_t id;
    uint16_t sequence;
};

struct ARP{
    uint16_t hw_type; //hw type
    uint16_t prot_type; //protocol type
    uint8_t hw_size; //hw len
    uint8_t prot_size; //proto len
    uint16_t opcode; //opcode
    uint8_t src_hw_mac[6];
    uint8_t src_proto[4];
    uint8_t dst_hw_mac[6];
    uint8_t dst_proto[4];
};

struct UDP{
    uint16_t src_port;
    uint16_t dst_port;
    uint16_t len;
    uint16_t checksum;

};

struct TCP{
    uint16_t srcport;
    uint16_t dstport;
    uint32_t seq_raw;
    uint32_t ack_raw;
    uint8_t flags_ae;
    uint8_t flags_fin;
    uint16_t window_size_value;
    uint16_t checksum;
    uint16_t urgent_pointer;
};


struct PseudoHeader {
    uint32_t src_addr;
    uint32_t dst_addr;
    uint8_t zero;
    uint8_t protocol;
    uint16_t tcp_length;
};

#endif
